package com.github.jianlu8023.java.format;

import java.util.HashMap;

public class AjaxResult extends HashMap<String, Object> {

    public static AjaxResult success(int code) {
        AjaxResult json = new AjaxResult();
        json.put("success", true);
        json.put("message", "业务处理成功");
        json.put("code", code);
        json.put("obj", (Object) null);
        ServletUtil.getResponse().setStatus(200);
        return json;
    }

    public static AjaxResult success(int code, Object obj) {
        AjaxResult json = new AjaxResult();
        json.put("success", true);
        json.put("message", "业务处理成功");
        json.put("code", code);
        json.put("obj", obj);
        ServletUtil.getResponse().setStatus(200);
        return json;
    }

    public static AjaxResult success(int code, String message, Object obj) {
        AjaxResult json = new AjaxResult();
        json.put("success", true);
        json.put("message", message);
        json.put("code", code);
        json.put("obj", obj);
        ServletUtil.getResponse().setStatus(200);
        return json;
    }

    public static AjaxResult error(String msg) {
        return error(500, msg);
    }

    public static AjaxResult error(int code, String msg) {
        AjaxResult result = new AjaxResult();
        result.put("success", false);
        result.put("message", msg);
        result.put("code", code);
        result.put("obj", (Object) null);
        ServletUtil.getResponse().setStatus(200);
        return result;
    }

    public static AjaxResult error(int code, String msg, Object obj) {
        AjaxResult result = new AjaxResult();
        result.put("success", false);
        result.put("message", msg);
        result.put("code", code);
        result.put("obj", obj);
        ServletUtil.getResponse().setStatus(200);
        return result;
    }
}
