package com.github.jianlu8023.java.format;

public interface HttpStatusCOde {
    int GET_SUCCESS_CODE = 200;
    int PUT_SUCCESS_CODE = 200;
    int PATCH_SUCCESS_CODE = 200;
    int POST_SUCCESS_CODE = 201;
    int ASYNC_SUCCESS_CODE = 202;
    int DELETE_SUCCESS_CODE = 204;
    int ACCESS_DENIED = 401;
    int ACCESS_FORBIDDER = 403;
    int NOT_FOUND = 404;
    int BUSINESS_FAIL_CODE = 500;
}
