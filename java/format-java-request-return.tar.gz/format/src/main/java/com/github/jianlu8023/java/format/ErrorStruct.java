package com.github.jianlu8023.java.format;

import com.alibaba.fastjson.JSON;

public class ErrorStruct {
    private String errorTitle;

    private String errorDetail;

    public ErrorStruct(String title, String detail) {
        if (title == null || title.isEmpty()) {
            title = "发生不可预知错误";
        }
        if (detail == null || detail.isEmpty()) {
            detail = "详细信息请查看后台日志";
        }
        this.errorTitle = title;
        this.errorDetail = detail;
    }

    public String getErrorTitle() {
        return errorTitle;
    }

    public void setErrorTitle(String errorTitle) {
        this.errorTitle = errorTitle;
    }

    public String getErrorDetail() {
        return errorDetail;
    }

    public void setErrorDetail(String errorDetail) {
        this.errorDetail = errorDetail;
    }

    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }
}
